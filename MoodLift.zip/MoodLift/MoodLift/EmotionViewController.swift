import UIKit

class EmotionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!

    private let emotions = Emotion.allCases

    override func viewDidLoad() {
        super.viewDidLoad()
        configureTitleWithLogo()
        tableView.dataSource = self
        tableView.delegate = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        emotions.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmotionCell", for: indexPath)
        let emotion = emotions[indexPath.row]
        var config = cell.defaultContentConfiguration()
        config.text = emotion.rawValue
        config.secondaryText = subtitle(for: emotion)
        cell.contentConfiguration = config
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let selectedEmotion = emotions[indexPath.row]
        performSegue(withIdentifier: "showQuotes", sender: selectedEmotion)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showQuotes",
           let destination = segue.destination as? QuotesViewController,
           let emotion = sender as? Emotion {
            destination.selectedEmotion = emotion
        }
    }

    private func configureTitleWithLogo() {
        let imageView = UIImageView(image: UIImage(systemName: "applelogo"))
        imageView.tintColor = .label
        imageView.contentMode = .scaleAspectFit
        imageView.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 32, weight: .bold)
        imageView.setContentHuggingPriority(.required, for: .horizontal)

        let titleLabel = UILabel()
        titleLabel.text = "MoodLift"
        titleLabel.font = .systemFont(ofSize: 28, weight: .bold)
        titleLabel.textColor = .label

        let stack = UIStackView(arrangedSubviews: [imageView, titleLabel])
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = 6

        navigationItem.titleView = stack
    }

    private func subtitle(for emotion: Emotion) -> String {
        switch emotion {
        case .happy:
            return "Keep the momentum going"
        case .sad:
            return "Find hope and encouragement"
        case .stressed:
            return "Slow down and reset"
        case .angry:
            return "Regain perspective"
        case .unmotivated:
            return "Build discipline and action"
        }
    }
}
