import UIKit

protocol QuoteDetailViewControllerDelegate: AnyObject {
    func quoteDetailViewController(_ controller: QuoteDetailViewController, didFavorite quote: Quote)
}

class QuoteDetailViewController: UIViewController {
    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!

    weak var delegate: QuoteDetailViewControllerDelegate?
    var quote: Quote?
    var showsFavoriteButton = true

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Quote"

        let authorText = quote.map { "\n\n— \($0.author)" } ?? ""
        quoteLabel.text = (quote?.content ?? "No quote selected.") + authorText
        quoteLabel.numberOfLines = 0
        quoteLabel.textAlignment = .center

        favoriteButton.isHidden = !showsFavoriteButton
        favoriteButton.layer.cornerRadius = 10
    }

    @IBAction private func didTapFavorite(_ sender: UIButton) {
        guard let quote else { return }

        let added = FavoritesStore.add(quote)
        if added {
            delegate?.quoteDetailViewController(self, didFavorite: quote)
        }

        let title = added ? "Saved" : "Already Saved"
        let message = added ? "This quote was added to Favorites." : "This quote is already in Favorites."
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
