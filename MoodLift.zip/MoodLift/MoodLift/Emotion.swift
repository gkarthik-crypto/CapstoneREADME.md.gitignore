import Foundation

enum Emotion: String, CaseIterable {
    case happy = "Happy"
    case sad = "Sad"
    case stressed = "Stressed"
    case angry = "Angry"
    case unmotivated = "Unmotivated"
}
