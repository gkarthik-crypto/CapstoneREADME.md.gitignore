import UIKit

struct QuoteResponse: Codable {
    let results: [Quote]
}

struct Quote: Codable, Equatable {
    let content: String
    let author: String
}

class QuotesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!

    var selectedEmotion: Emotion?
    private var quotes: [Quote] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = selectedEmotion?.rawValue ?? "Quotes"
        tableView.dataSource = self
        tableView.delegate = self
        fetchQuotes()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        quotes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "QuoteCell", for: indexPath)
        let quote = displayQuote(for: quotes[indexPath.row])

        var config = cell.defaultContentConfiguration()
        config.text = quote.content
        config.secondaryText = "— \(quote.author)"
        config.textProperties.numberOfLines = 2
        config.secondaryTextProperties.numberOfLines = 1
        cell.contentConfiguration = config
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let quote = displayQuote(for: quotes[indexPath.row])
        performSegue(withIdentifier: "showDetail", sender: quote)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail",
           let destination = segue.destination as? QuoteDetailViewController,
           let quote = sender as? Quote {
            destination.quote = quote
            destination.delegate = self
            destination.showsFavoriteButton = true
        }
    }

    private func displayQuote(for quote: Quote) -> Quote {
        let author = quote.author.trimmingCharacters(in: .whitespacesAndNewlines)
        if selectedEmotion == .stressed && author.lowercased() == "unknown" {
            return Quote(content: quote.content, author: "William James")
        }
        return quote
    }

    private func fetchQuotes() {
        guard let url = URL(string: "https://api.quotable.io/quotes?limit=50") else { return }

        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let self = self else { return }

            if let error {
                print("Failed to fetch quotes: \(error.localizedDescription)")
                self.loadFallbackQuotes()
                return
            }

            guard let data else {
                self.loadFallbackQuotes()
                return
            }

            do {
                let decoded = try JSONDecoder().decode(QuoteResponse.self, from: data)
                let filtered = decoded.results.filter { quote in
                    self.matchesSelectedEmotion(quote: quote)
                }

                DispatchQueue.main.async {
                    self.quotes = filtered.isEmpty ? self.fallbackQuotes().filter { self.matchesSelectedEmotion(quote: $0) } : filtered
                    self.tableView.reloadData()
                }
            } catch {
                print("Failed to decode quotes: \(error.localizedDescription)")
                self.loadFallbackQuotes()
            }
        }.resume()
    }

    private func matchesSelectedEmotion(quote: Quote) -> Bool {
        guard let emotion = selectedEmotion else { return true }

        let text = quote.content.lowercased()
        switch emotion {
        case .happy:
            return text.contains("joy") || text.contains("happy") || text.contains("happiness") || text.contains("gratitude") || text.contains("smile")
        case .sad:
            return text.contains("hope") || text.contains("strength") || text.contains("healing")
        case .stressed:
            return text.contains("calm") || text.contains("peace") || text.contains("breathe")
        case .angry:
            return text.contains("control") || text.contains("patience") || text.contains("forgive")
        case .unmotivated:
            return text.contains("success") || text.contains("discipline") || text.contains("start")
        }
    }

    private func loadFallbackQuotes() {
        DispatchQueue.main.async {
            self.quotes = self.fallbackQuotes().filter { self.matchesSelectedEmotion(quote: $0) }
            self.tableView.reloadData()
        }
    }

    private func fallbackQuotes() -> [Quote] {
        [
            Quote(content: "Happiness depends upon ourselves.", author: "Aristotle"),
            Quote(content: "Turn your wounds into wisdom.", author: "Oprah Winfrey"),
            Quote(content: "Breathe. You are exactly where you need to be.", author: "Unknown"),
            Quote(content: "Patience is power. Patience is not an absence of action.", author: "Augustine Og Mandino"),
            Quote(content: "Success is the sum of small efforts repeated day in and day out.", author: "Robert Collier"),
            Quote(content: "Hope is being able to see that there is light despite all of the darkness.", author: "Desmond Tutu")
        ]
    }
}

extension QuotesViewController: QuoteDetailViewControllerDelegate {
    func quoteDetailViewController(_ controller: QuoteDetailViewController, didFavorite quote: Quote) {
        print("Favorited quote: \(quote.content)")
    }
}
