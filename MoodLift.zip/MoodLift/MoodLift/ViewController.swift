//
//  ViewController.swift
//  MoodLift
//
//  Created by Gokkul Karthikeyan on 4/22/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

