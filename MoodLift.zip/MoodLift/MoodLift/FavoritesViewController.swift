import UIKit

class FavoritesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!

    private var favorites: [Quote] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Favorites"
        tableView.dataSource = self
        tableView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        favorites = FavoritesStore.load()
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        favorites.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoriteCell", for: indexPath)
        let quote = favorites[indexPath.row]

        var config = cell.defaultContentConfiguration()
        config.text = quote.content
        config.secondaryText = "— \(quote.author)"
        config.textProperties.numberOfLines = 2
        config.secondaryTextProperties.numberOfLines = 1
        cell.contentConfiguration = config
        cell.accessoryType = .disclosureIndicator

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "showFavoriteDetail", sender: favorites[indexPath.row])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showFavoriteDetail",
           let destination = segue.destination as? QuoteDetailViewController,
           let quote = sender as? Quote {
            destination.quote = quote
            destination.showsFavoriteButton = false
        }
    }
}
