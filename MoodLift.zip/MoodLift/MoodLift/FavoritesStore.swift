import Foundation

enum FavoritesStore {
    private static let key = "favorites"

    static func load() -> [Quote] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let saved = try? JSONDecoder().decode([Quote].self, from: data) else {
            return []
        }
        return saved
    }

    static func save(_ quotes: [Quote]) {
        let data = try? JSONEncoder().encode(quotes)
        UserDefaults.standard.set(data, forKey: key)
    }

    @discardableResult
    static func add(_ quote: Quote) -> Bool {
        var favorites = load()
        guard favorites.contains(quote) == false else {
            return false
        }
        favorites.insert(quote, at: 0)
        save(favorites)
        return true
    }
}
